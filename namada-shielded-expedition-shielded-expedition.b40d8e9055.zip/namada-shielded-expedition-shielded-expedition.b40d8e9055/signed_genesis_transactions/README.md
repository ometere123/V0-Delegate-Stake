# Signed Genesis Transactions

Please follow (the docs)[https://docs.namada.net/operators/networks/genesis-flow/participants\#generate-a-pre-genesis-validator-account] in order to submit genesis transactions. The `balances.toml` with corresponding `NAAN` allocations can be found in the root of this repository.
